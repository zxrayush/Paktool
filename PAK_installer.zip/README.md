
Ekstrak semua file dan letakkan di folder /sdcard/Download
Extract all files into /sdcard/Download

Jalankan perintah dibawah ini di termux. 
Run this command in termux. 

Perintah/Command :

termux-setup-storage

bash /sdcard/Download/paktool_installer